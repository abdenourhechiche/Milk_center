@echo off
REM ============================================================
REM  Compilation Centre Collecte Lait pour Windows 7+
REM  Compatible 32 bits ET 64 bits
REM ============================================================
REM
REM  IMPORTANT :
REM  - Pour Windows 7 32 bits ET 64 bits : utilisez Python 3.6, 3.7 ou 3.8
REM    en version 32 bits (x86). Un exe 32 bits tourne aussi sur 64 bits.
REM  - Python 3.9+ ne supporte plus officiellement Windows 7.
REM
REM  Etapes :
REM  1. Installer Python 3.6 / 3.7 / 3.8 32 bits depuis python.org
REM  2. Ouvrir "Invite de commandes" dans ce dossier
REM  3. Lancer : build.bat
REM ============================================================

echo.
echo === Compilation Centre Collecte Lait ===
echo.

python --version
if errorlevel 1 (
    echo ERREUR : Python introuvable. Ajoutez-le au PATH.
    pause
    exit /b 1
)

echo.
echo [1/3] Installation de PyInstaller...
python -m pip install --upgrade pip
python -m pip install "pyinstaller>=3.6,<5"

echo.
echo [2/3] Nettoyage anciens builds...
if exist build rmdir /s /q build
if exist dist rmdir /s /q dist

echo.
echo [3/3] Compilation (cela peut prendre 1 a 3 minutes)...
python -m PyInstaller --noconfirm milk_lite.spec

if errorlevel 1 (
    echo.
    echo ERREUR pendant la compilation.
    pause
    exit /b 1
)

echo.
echo ============================================================
echo  SUCCES
echo ============================================================
echo.
echo  L'executable se trouve dans :
echo    dist\CentreCollecteLait\
echo.
echo  Fichier principal :
echo    dist\CentreCollecteLait\CentreCollecteLait.exe
echo.
echo  Copiez TOUT le dossier "CentreCollecteLait" sur le PC cible.
echo  (Windows 7 32/64 bits, Windows 8, 10, 11)
echo.
echo  Compte : admin / admin123
echo ============================================================
pause
