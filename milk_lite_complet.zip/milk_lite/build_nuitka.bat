@echo off
REM ============================================================
REM  Compilation avec NUITKA - Centre Collecte Lait
REM  Compatible Windows 7 32/64 bits et superieur
REM ============================================================
REM
REM  Prerequisites :
REM  1. Python 3.6 / 3.7 / 3.8 32 bits (pour max compat Win7)
REM  2. Un compilateur C :
REM     - MinGW64  OU
REM     - Visual Studio Build Tools (C++)
REM
REM  Lancer ce script depuis le dossier milk_lite
REM ============================================================

echo.
echo === Compilation Nuitka - Centre Collecte Lait ===
echo.

python --version
if errorlevel 1 (
    echo ERREUR : Python introuvable dans le PATH.
    pause
    exit /b 1
)

echo.
echo [1/4] Installation / mise a jour de Nuitka...
python -m pip install --upgrade pip
python -m pip install "nuitka" ordered-set zstandard

if errorlevel 1 (
    echo.
    echo Echec pip. Essayez :
    echo   python -m pip install nuitka==0.6.19
    echo pour Python 3.6
    pause
    exit /b 1
)

echo.
echo [2/4] Verification Nuitka...
python -m nuitka --version
if errorlevel 1 (
    echo ERREUR : Nuitka non trouve. python -m nuitka --version
    pause
    exit /b 1
)

echo.
echo [3/4] Nettoyage...
if exist main.build rmdir /s /q main.build
if exist main.dist rmdir /s /q main.dist
if exist CentreCollecteLait.dist rmdir /s /q CentreCollecteLait.dist
if exist dist_nuitka rmdir /s /q dist_nuitka

echo.
echo [4/4] Compilation Nuitka (peut prendre 5 a 15 minutes)...
echo.

REM --standalone : dossier autonome avec toutes les DLL
REM --windows-disable-console : pas de fenetre noire
REM --enable-plugin=tk-inter : support Tkinter
REM --follow-imports : inclure src.*
REM --include-package=src : forcer le package

python -m nuitka ^
  --standalone ^
  --windows-disable-console ^
  --enable-plugin=tk-inter ^
  --follow-imports ^
  --include-package=src ^
  --output-dir=dist_nuitka ^
  --output-filename=CentreCollecteLait.exe ^
  --assume-yes-for-downloads ^
  main.py

if errorlevel 1 (
    echo.
    echo ============================================================
    echo  ECHEC de compilation
    echo ============================================================
    echo.
    echo Causes frequentes :
    echo  1. Compilateur C absent
    echo     - Installez MinGW-w64 OU Visual Studio Build Tools
    echo  2. Python trop recent pour Windows 7 (utilisez 3.6-3.8)
    echo  3. Nuitka trop recent pour Python 3.6
    echo     Essayez : python -m pip install "nuitka==0.6.19"
    echo.
    echo Voir COMPILER.txt pour le detail.
    pause
    exit /b 1
)

echo.
echo ============================================================
echo  SUCCES
echo ============================================================
echo.
echo  Resultat dans :
echo    dist_nuitka\main.dist\
echo    ou
echo    dist_nuitka\CentreCollecteLait.dist\
echo.
echo  Cherchez CentreCollecteLait.exe (ou main.exe) dans ce dossier.
echo  Copiez TOUT le dossier .dist sur le PC cible.
echo.
echo  Compte : admin / admin123
echo ============================================================
pause
